XX.fit -> missing data image, input to inla code
XX_mass_inla.fit -> output file from inla code (restored image)
XX_diff.fit -> original (without missing data) - restored image
